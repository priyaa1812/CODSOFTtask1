package javatraining;
//area perimeter of circle
import java.util.Scanner;
class area1{
	int radius;
	double area;
	double p;
	void area() {
		Scanner obj=new Scanner(System.in);
        System.out.println("Enter the radius:");
		radius=obj.nextInt();
		double area=(radius*radius*3.14);
		System.out.println("Area of circle:"+area);
		
        
	}
}
class perimeter extends area1{
	void perimeter() {
		Scanner obj=new Scanner(System.in);
		System.out.println("Enter the radius:");
		radius=obj.nextInt();
		double p=(radius*2*3.14);
		System.out.println("Perimeter of circle:"+p);
		
        
	}
}
public class test1 {
	

	public static void main(String[] args) {
		
		perimeter obj=new perimeter();
		obj.area();
		obj.perimeter();

	}

}

